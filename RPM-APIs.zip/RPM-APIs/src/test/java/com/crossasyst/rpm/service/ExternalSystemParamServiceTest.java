package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.entity.ExternalSystemParamEntity;
import com.crossasyst.rpm.mapper.ExternalSystemParamMapper;
import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.repository.ExternalSystemParamRepository;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalSystemParamResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ExternalSystemParamServiceTest {

    ExternalSystemParamService externalSystemParamService;
    ExternalSystemParamRepository externalSystemParamRepository;
    ExternalSystemParamMapper externalSystemParamMapper;
    ExternalSystemRepository externalSystemRepository;


    @BeforeEach
    void setUp() {
        externalSystemRepository = mock(ExternalSystemRepository.class);
        externalSystemParamRepository = mock(ExternalSystemParamRepository.class);
        externalSystemParamMapper = mock(ExternalSystemParamMapper.class);
        externalSystemParamService = new ExternalSystemParamService(externalSystemParamRepository, externalSystemRepository, externalSystemParamMapper);
    }

    @Test
    void testCreateExternalSystemParam() {
        ExternalSystemParam externalSystemParam = new ExternalSystemParam();
        externalSystemParam.setKey("alpha");
        externalSystemParam.setValue("sierra");

        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setExternalSystemId(1L);
        ExternalSystemParamEntity externalSystemParamEntities = new ExternalSystemParamEntity();
        externalSystemParamEntities.setExternalSystem(externalSystemEntity);
        externalSystemParamEntities.setExternalSystemParamId(1L);
        externalSystemParamEntities.setKey("alpha");
        externalSystemParamEntities.setValue("sierra");

        ExternalSystemParamResponse externalSystemParamResponse = new ExternalSystemParamResponse();
        externalSystemParamResponse.setExternalSystemParamId(1L);

        when(externalSystemRepository.findById(1L)).thenReturn(Optional.of(externalSystemEntity));
        when(externalSystemParamMapper.modelToEntity(any(ExternalSystemParam.class))).thenReturn(externalSystemParamEntities);
        when(externalSystemParamRepository.save(any(ExternalSystemParamEntity.class))).thenReturn(externalSystemParamEntities);
        ExternalSystemParamResponse response = externalSystemParamService.createExternalSystemParam(1L, externalSystemParam);
        assertNotNull(response);
        assertEquals(externalSystemParamResponse, response);
    }

    @Test
    void testGetAllExternalSystemParam() {
        ExternalSystemParamResponse externalSystemParamResponse = new ExternalSystemParamResponse();
        externalSystemParamResponse.setKey("ABC");
        externalSystemParamResponse.setValue("XYZ");
        externalSystemParamResponse.setExternalSystemParamId(2L);
        List<ExternalSystemParamResponse> externalSystemParamResponseList = List.of(externalSystemParamResponse);
        List<ExternalSystemParamEntity> externalSystemParamEntityList = List.of(externalSystemParamEntity());
        when(externalSystemRepository.findById(1L)).thenReturn(Optional.of(externalSystemEntity()));
        when(externalSystemParamRepository.findByExternalSystemId(1L)).thenReturn(externalSystemParamEntityList);
        when(externalSystemParamMapper.entityToModel(externalSystemParamEntityList)).thenReturn(externalSystemParamResponseList);
        List<ExternalSystemParamResponse> responseList = externalSystemParamService.getAllExternalSystemParam(1L);
        assertNotNull(responseList);
        assertEquals(externalSystemParamResponseList, responseList);
    }


    @Test
    void testGetExternalSystemParamById() {
        ExternalSystemParam externalSystemParam = externalSystemParam();
        when(externalSystemRepository.findById(1L)).thenReturn(Optional.of(externalSystemEntity()));
        when(externalSystemParamRepository.findById(2L)).thenReturn(Optional.of(externalSystemParamEntity()));
        when(externalSystemParamMapper.entityToModel(externalSystemParamEntity())).thenReturn(externalSystemParam());
        ExternalSystemParam response = externalSystemParamService.getExternalSystemParamById(1L, 2L);
        assertNotNull(response);
        assertEquals(externalSystemParam, response);
    }


    @Test
    void testUpdateExternalSystemParam() {

        ExternalSystemParam externalSystemParam = externalSystemParam();
        when(externalSystemRepository.findById(1L)).thenReturn(Optional.ofNullable(externalSystemEntity()));
        when(externalSystemParamRepository.findById(2L)).thenReturn(Optional.of(externalSystemParamEntity()));
        when(externalSystemParamMapper.modelToEntity(externalSystemParam)).thenReturn(externalSystemParamEntity());
        externalSystemParamService.updateExternalSystemParam(1L, 2L, externalSystemParam);
        verify(externalSystemParamRepository, times(1)).save(externalSystemParamEntity());
    }


    ExternalSystemParam externalSystemParam() {
        ExternalSystemParam externalSystemParam = new ExternalSystemParam();
        externalSystemParam.setKey("1X");
        externalSystemParam.setValue("ABC");
        return externalSystemParam;

    }

    ExternalSystemEntity externalSystemEntity() {
        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setName("ABC");
        externalSystemEntity.setExternalSystemId(1L);
        return externalSystemEntity;
    }

    ExternalSystemParamEntity externalSystemParamEntity() {

        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setName("ABC");
        externalSystemEntity.setExternalSystemId(1L);

        ExternalSystemParamEntity externalSystemParamEntity = new ExternalSystemParamEntity();
        externalSystemParamEntity.setKey("1X");
        externalSystemParamEntity.setValue("ABC");
        externalSystemParamEntity.setExternalSystemParamId(2L);
        externalSystemParamEntity.setExternalSystem(externalSystemEntity);
        return externalSystemParamEntity;
    }
}

