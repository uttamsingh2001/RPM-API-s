package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.PatientObs;
import com.crossasyst.rpm.response.PatientObsResponse;
import com.crossasyst.rpm.service.PatientObsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)

public class PatientObsControllerTest {

    PatientObsController patientObsController;
    PatientObsService patientObsService;

    @BeforeEach
    void setUp() {
        patientObsService = mock(PatientObsService.class);
        patientObsController = new PatientObsController(patientObsService);
    }

    @Test
    void testCreatePatientObs() {
        PatientObs mockPatientObs = new PatientObs();
        PatientObsResponse mockPatientObsResponse = new PatientObsResponse();
        when(patientObsService.createPatientObs(any(PatientObs.class))).thenReturn(mockPatientObsResponse);
        ResponseEntity<PatientObsResponse> response = patientObsController.createPatientObs(mockPatientObs);
        verify(patientObsService, times(1)).createPatientObs(mockPatientObs);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    void testGetPatientObsDetail() {
        List<PatientObsResponse> patientObsResponseList = new ArrayList<>();
        PatientObsResponse patientObsResponse = new PatientObsResponse();
        patientObsResponse.setPatientObsId(1L);
        patientObsResponse.setValue(121D);
        patientObsResponse.setUomCode("uom");
        patientObsResponse.setObstermId(1000L);
        patientObsResponse.setEffectiveDateTime(LocalDateTime.parse("2023-04-28T15:30:00"));
        patientObsResponseList.add(patientObsResponse);
        when(patientObsService.getPatientObs(anyLong())).thenReturn(patientObsResponseList);
        ResponseEntity<List<PatientObsResponse>> response = patientObsController.getPatientObs(anyLong());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(CollectionUtils.isEmpty(response.getBody()));
        verify(patientObsService, times(1)).getPatientObs(anyLong());


    }

    @Test
    void testGetPatientObsDetailNoContentTest() {
        when(patientObsService.getPatientObs(anyLong())).thenReturn(Collections.emptyList());
        ResponseEntity<List<PatientObsResponse>> response = patientObsController.getPatientObs(anyLong());
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertTrue(CollectionUtils.isEmpty(response.getBody()));
        verify(patientObsService, times(1)).getPatientObs(anyLong());


    }
}
