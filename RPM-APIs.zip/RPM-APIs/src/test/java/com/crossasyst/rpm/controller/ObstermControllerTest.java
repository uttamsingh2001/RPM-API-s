package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.Obsterm;
import com.crossasyst.rpm.response.ObstermResponse;
import com.crossasyst.rpm.service.ObstermService;
import com.crossasyst.rpm.testUtils.MockUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ObstermControllerTest {

    ObstermController obstermController;
    ObstermService obstermService;

    @BeforeEach
    void setUp() {
        obstermService = mock(ObstermService.class);
        obstermController = new ObstermController(obstermService);
    }

    @Test
    void testGetAllObsterm() {
        ObstermResponse obstermResponse = new ObstermResponse();
        obstermResponse.setObstermId(1L);
        obstermResponse.setObstypeId(2L);
        obstermResponse.setName("ABC");
        obstermResponse.setObscategoryId(100L);
        obstermResponse.setCode("XYZ");
        List<ObstermResponse> obstermResponseList = List.of(obstermResponse);
        when(obstermService.getAllObsterm()).thenReturn(obstermResponseList);
        ResponseEntity<List<ObstermResponse>> response = obstermController.getAllObsterm();
        assertEquals(obstermResponseList, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }


    @Test
    void testGetObsterm() {
        when(obstermService.getObsterm(anyLong())).thenReturn(MockUtils.obsterm());
        ResponseEntity<Obsterm> response = obstermController.getObsterm(anyLong());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(MockUtils.obsterm(), response.getBody());
    }
}
