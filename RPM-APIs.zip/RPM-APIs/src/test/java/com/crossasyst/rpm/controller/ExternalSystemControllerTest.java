package com.crossasyst.rpm.controller;



import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.response.ExternalSystemResponse;
import com.crossasyst.rpm.service.ExternalSystemService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
class ExternalSystemControllerTest {
    private static final String Path_Create_ExternalSystem="/v1/externalSystems";

    private static final String Path_UPDATE_EXTERNALSYSTEM_BY_ID="/v1/externalSystems/1";
    private static final String Path_GET_EXTERNALSYSTEM_BY_ID="/v1/externalSystems/1";

    @InjectMocks
    private ExternalSystemController externalSystemController;


    @Mock
    ExternalSystemService externalSystemService;
    ExternalSystemResponse externalSystemResponse;

    JacksonTester<ExternalSystem> jsonExternalSystem;



    MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(externalSystemController).build();
        ObjectMapper mapper = new ObjectMapper();
        JacksonTester.initFields(this, mapper);

    }

    @Test
    void testCreateExternalSystem() throws Exception {
        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("ihealth");

        when(externalSystemService.createExternalSystem(Mockito.any(ExternalSystem.class))).thenReturn(externalSystemResponse);
        mockMvc.perform(MockMvcRequestBuilders.post(Path_Create_ExternalSystem).contentType(MediaType.APPLICATION_JSON)
                        .content(jsonExternalSystem.write(externalSystem).getJson()))
                .andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
        Mockito.verify(externalSystemService, times(1)).createExternalSystem(externalSystem);
    }

    @Test
    void testGetExternalSystem() throws Exception {
        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("ihealth");

        when(externalSystemService.getExternalSystem(anyLong())).thenReturn(new ExternalSystem());
        mockMvc.perform(MockMvcRequestBuilders.get(Path_GET_EXTERNALSYSTEM_BY_ID))
                .andExpect(MockMvcResultMatchers.status().isFound());
        Mockito.verify(externalSystemService, times(1)).getExternalSystem(anyLong());
    }

    @Test
    void testUpdate() throws Exception {
        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("medlink");

        when(externalSystemService.updateExternalSystem(1L, externalSystem)).thenReturn(externalSystem);
        MockHttpServletResponse response = mockMvc.perform(MockMvcRequestBuilders.put(Path_UPDATE_EXTERNALSYSTEM_BY_ID)
                        .contentType(MediaType.APPLICATION_JSON).content(jsonExternalSystem.write(externalSystem).getJson()))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn()
                .getResponse();
        Mockito.verify(externalSystemService, times(1)).updateExternalSystem(1L, externalSystem);
    }

    @Test
    void testGetAllExternalSystem()throws Exception{
        List<ExternalSystemResponse> expectedExternalSystems = List.of(
                new ExternalSystemResponse(1L),
                new ExternalSystemResponse(1L)
        );
        when(externalSystemService.getAllExternalSystem()).thenReturn(expectedExternalSystems);

        ExternalSystemController controller = new ExternalSystemController(externalSystemService);

        ResponseEntity<List<ExternalSystemResponse>> response = controller.getAllExternalSystem();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedExternalSystems, response.getBody());
    }
}