package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.Enterprise;
import com.crossasyst.rpm.response.EnterpriseResponse;
import com.crossasyst.rpm.service.EnterpriseService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

class EnterpriseControllerTest {

    private EnterpriseController enterpriseController;
    private EnterpriseService enterpriseService;

    @BeforeEach
    void setUp() {
        enterpriseService = mock(EnterpriseService.class);
        enterpriseController = new EnterpriseController(enterpriseService);
    }

    @Test
    void testCreateEnterprise() {
        EnterpriseResponse enterpriseResponse = new EnterpriseResponse();
        Enterprise enterprise = new Enterprise();
        when(enterpriseService.createEnterprise(any())).thenReturn(enterpriseResponse);
        ResponseEntity<EnterpriseResponse> response = enterpriseController.createEnterprise(enterprise);
        Assertions.assertNotNull(response);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }


    @Test
    void testGetEnterPrise() {
        EnterpriseResponse enterpriseResponse = new EnterpriseResponse();
        when(enterpriseService.getEnterprise(anyLong())).thenReturn(enterpriseResponse);
        ResponseEntity<Enterprise> response = enterpriseController.getEnterprise(1L);
        Assertions.assertNotNull(response);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testGetAllEnterprise() {
        EnterpriseResponse enterprise = new EnterpriseResponse(1L);
        enterprise.setName("ABC");
        EnterpriseResponse enterprise1 = new EnterpriseResponse(2L);
        enterprise.setName("XYZ");
        List<EnterpriseResponse> responseList = List.of(enterprise, enterprise1);
        when(enterpriseService.getAllEnterprise()).thenReturn((responseList));
        ResponseEntity<List<EnterpriseResponse>> allEnterprise = enterpriseController.getAllEnterprise();
        Assertions.assertEquals(HttpStatus.OK, allEnterprise.getStatusCode());

    }

    @Test
    void testUpdateEnterprise() {
        Enterprise enterprise = new Enterprise();
        enterprise.setName("ABC");
        enterpriseController.updateEnterprise(1L, enterprise);
        verify(enterpriseService, times(1)).updateEnterprise(anyLong(), any(Enterprise.class));

    }

    @Test
    void testRemoveEnterpriseTest() {
        enterpriseController.removeEnterprise(1L);
        verify(enterpriseService, times(1)).removeEnterprise(any());
    }
}


