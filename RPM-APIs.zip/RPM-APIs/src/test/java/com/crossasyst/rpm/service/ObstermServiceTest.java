package com.crossasyst.rpm.service;


import com.crossasyst.rpm.entity.ObstermEntity;
import com.crossasyst.rpm.mapper.ObstermMapper;
import com.crossasyst.rpm.model.Obsterm;
import com.crossasyst.rpm.repository.ObstermRepository;
import com.crossasyst.rpm.response.ObstermResponse;
import com.crossasyst.rpm.testUtils.MockUtils;
import com.crossasyst.rpm.utils.CustomExceptionHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class ObstermServiceTest {
    @InjectMocks
    ObstermService obstermService;
    @Mock
    ObstermRepository obstermRepository;

    @BeforeEach
    void setUp() {
        ObstermMapper obstermMapper = Mappers.getMapper(ObstermMapper.class);
        ReflectionTestUtils.setField(obstermService, "obstermMapper", obstermMapper);
    }


    @Test
    void testGetAllObsterm() {

        List<ObstermEntity> obstermEntityList = List.of(MockUtils.obstermEntity());
        ObstermResponse obstermResponse = new ObstermResponse();
        obstermResponse.setCode("XYZ");
        obstermResponse.setObscategoryId(1000L);
        obstermResponse.setObstermId(1L);
        obstermResponse.setObstypeId(100L);
        obstermResponse.setName("ABC");
        List<ObstermResponse> obstermResponseList = List.of(obstermResponse);
        when(obstermRepository.findAll()).thenReturn(obstermEntityList);
        List<ObstermResponse> response = obstermService.getAllObsterm();
        assertNotNull(response);
        assertEquals(obstermResponseList, response);

    }

    @Test
    void testGetAllObstermIsEmpty() {
        List<ObstermEntity> obstermEntities = new ArrayList<>();
        when(obstermRepository.findAll()).thenReturn(obstermEntities);
        List<ObstermResponse> response = obstermService.getAllObsterm();
        assertNotNull(response);
        assertEquals(Collections.emptyList(), response);
    }


    @Test
    void testGetObsterm() {
        ObstermEntity obstermEntity = MockUtils.obstermEntity();
        when(obstermRepository.findById(anyLong())).thenReturn(Optional.of(obstermEntity));
        Obsterm response = obstermService.getObsterm(anyLong());
        assertNotNull(response);
        assertEquals(MockUtils.obsterm(), response);
    }

    @Test
    void testGetObstermException() {
        when(obstermRepository.findById(anyLong())).thenThrow(CustomExceptionHandler.class);
        Throwable exception = assertThrows(CustomExceptionHandler.class, () -> obstermService.getObsterm(anyLong()));
        assertEquals(new CustomExceptionHandler().getMessage(), exception.getMessage());
    }


}
