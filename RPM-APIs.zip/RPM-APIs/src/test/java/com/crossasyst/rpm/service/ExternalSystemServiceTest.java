package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.mapper.ExternalSystemMapper;
import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalSystemResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ExternalSystemServiceTest {

    ExternalSystemService externalSystemService;
    ExternalSystemRepository externalSystemRepository;
    ExternalSystemMapper externalSystemMapper;


    @BeforeEach
    void setUp() {
        externalSystemRepository = mock(ExternalSystemRepository.class);
        externalSystemMapper = mock(ExternalSystemMapper.class);
        externalSystemService = new ExternalSystemService(externalSystemRepository, externalSystemMapper);
    }

    @Test
    void testCreateExternalSystem() {
        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("ABC");

        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setExternalSystemId(1L);
        externalSystemEntity.setName("ABC");

        ExternalSystemResponse externalSystemResponse = new ExternalSystemResponse();
        externalSystemResponse.setExternalSystemId(1L);

        when(externalSystemMapper.modelToEntity(any(ExternalSystem.class))).thenReturn(externalSystemEntity);
        when(externalSystemRepository.save(any(ExternalSystemEntity.class))).thenReturn(externalSystemEntity);
        ExternalSystemResponse response = externalSystemService.createExternalSystem(externalSystem);
        assertNotNull(response);
        assertEquals(externalSystemResponse, response);
    }

    @Test
    void testGetExternalSystem() {
        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setName("shiva");
        externalSystemEntity.setExternalSystemId(12L);

        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("shiva");
        when(externalSystemRepository.findById(externalSystemEntity.getExternalSystemId())).thenReturn(Optional.of(externalSystemEntity));
        when(externalSystemMapper.entityToModel(externalSystemEntity)).thenReturn(externalSystem);
        ExternalSystem response = externalSystemService.getExternalSystem(externalSystemEntity.getExternalSystemId());
        Assertions.assertNotNull(response);
        Assertions.assertEquals(externalSystemEntity.getName(), response.getName());
    }

    @Test
    void testGetAllExternalSystem() {
        ExternalSystemResponse externalSystemResponse = new ExternalSystemResponse();
        externalSystemResponse.setExternalSystemId(1000L);
        externalSystemResponse.setName("ABC");
        List<ExternalSystemResponse> externalSystemResponseList = List.of(externalSystemResponse);
        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setName("ABC");
        externalSystemEntity.setExternalSystemId(1000L);
        List<ExternalSystemEntity> externalSystemEntityList = List.of(externalSystemEntity);
        when(externalSystemRepository.findAll()).thenReturn(externalSystemEntityList);
        when(externalSystemMapper.EntityToModel(externalSystemEntityList)).thenReturn(externalSystemResponseList);
        List<ExternalSystemResponse> responseList = externalSystemService.getAllExternalSystem();
        assertNotNull(responseList);
        assertEquals(externalSystemResponseList, responseList);
    }


    @Test
    void testUpdateExternalSystem() {
        ExternalSystem externalSystem = new ExternalSystem();
        externalSystem.setName("shiva");
        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setName("shiva");
        externalSystemEntity.setExternalSystemId(12L);
        when(externalSystemRepository.findById(externalSystemEntity.getExternalSystemId())).thenReturn(Optional.of(externalSystemEntity));
        when(externalSystemMapper.modelToEntity(externalSystem)).thenReturn(externalSystemEntity);
        when(externalSystemRepository.save(externalSystemEntity)).thenReturn(externalSystemEntity);
        ExternalSystem response = externalSystemService.updateExternalSystem(externalSystemEntity.getExternalSystemId(), externalSystem);
        assertNotNull(response);
        assertEquals(externalSystem, response);
    }

}

