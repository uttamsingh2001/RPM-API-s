package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import com.crossasyst.rpm.mapper.PatientObsDetailMapper;
import com.crossasyst.rpm.repository.PatientObsDetailRepository;
import com.crossasyst.rpm.response.PatientObsDetailResponse;
import com.crossasyst.rpm.testUtils.MockUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PatientObsDetailServiceTest {

    @InjectMocks
    PatientObsDetailService patientObsDetailService;


    @Mock
    PatientObsDetailRepository patientObsDetailRepository;

    @BeforeEach
    void setUp() {
        PatientObsDetailMapper patientObsDetailMapper = Mappers.getMapper(PatientObsDetailMapper.class);
        ReflectionTestUtils.setField(patientObsDetailService, "patientObsDetailMapper", patientObsDetailMapper);
    }


    @Test
    void testGetAllPatientObs() {
        List<PatientObsDetailResponse> patientObsDetailResponseList = new ArrayList<>();
        patientObsDetailResponseList.add(MockUtils.getPatientObsResponse());
        List<PatientObsDetailEntity> patientObsDetailEntityList = new ArrayList<>();
        patientObsDetailEntityList.add(MockUtils.getPatientObsDetailEntity());
        when(patientObsDetailRepository.findByPatientObsId(anyLong())).thenReturn(patientObsDetailEntityList);
        List<PatientObsDetailResponse> response = patientObsDetailService.getAllPatientObs(anyLong());
        assertNotNull(response);
        assertEquals(patientObsDetailResponseList, response);

    }


    @Test
    void testGetAllPatientObsIsEmpty() {
        List<PatientObsDetailEntity> patientObsDetailEntityList = new ArrayList<>();
        when(patientObsDetailRepository.findByPatientObsId(anyLong())).thenReturn(patientObsDetailEntityList);
        List<PatientObsDetailResponse> response = patientObsDetailService.getAllPatientObs(anyLong());
        assertNotNull(response);
        assertEquals(Collections.emptyList(), response);
    }
}
