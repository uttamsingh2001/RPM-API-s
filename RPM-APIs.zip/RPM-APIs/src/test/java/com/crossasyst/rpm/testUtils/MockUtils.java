package com.crossasyst.rpm.testUtils;

import com.crossasyst.rpm.entity.ObsCategoryEntity;
import com.crossasyst.rpm.entity.ObstermEntity;
import com.crossasyst.rpm.entity.ObstypeEntity;
import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import com.crossasyst.rpm.entity.PatientObsEntity;
import com.crossasyst.rpm.model.Obsterm;
import com.crossasyst.rpm.response.ObstermResponse;
import com.crossasyst.rpm.response.PatientObsDetailResponse;


public class MockUtils {

    public static PatientObsDetailResponse getPatientObsResponse() {
        PatientObsDetailResponse patientObsDetailResponse = new PatientObsDetailResponse();
        patientObsDetailResponse.setPatientObsDetailId(1L);
        patientObsDetailResponse.setObstermId(1000L);
        patientObsDetailResponse.setObstypeId(1100L);
        return patientObsDetailResponse;
    }

    public static PatientObsDetailEntity getPatientObsDetailEntity() {
        PatientObsDetailEntity patientObsDetailEntity = new PatientObsDetailEntity();
        PatientObsEntity patientObsEntity = new PatientObsEntity();
        ObstermEntity obstermEntity = new ObstermEntity();
        ObstypeEntity obstypeEntity = new ObstypeEntity();
        obstypeEntity.setObstypeId(1100L);
        obstermEntity.setObstermId(1000L);
        patientObsEntity.setPatientObsId(1L);
        patientObsDetailEntity.setPatientObsDetailId(1L);
        patientObsDetailEntity.setPatientObs(patientObsEntity);
        patientObsDetailEntity.setObsterm(obstermEntity);
        patientObsDetailEntity.setObstype(obstypeEntity);
        return patientObsDetailEntity;
    }

    public static Obsterm obsterm() {
        Obsterm obsterm = new Obsterm();
        obsterm.setCode("XYZ");
        obsterm.setObstypeId(100L);
        obsterm.setName("ABC");
        obsterm.setObscategoryId(1000L);
        return obsterm;
    }

    public static ObstermEntity obstermEntity() {
        ObstermEntity obstermEntity = new ObstermEntity();
        ObstypeEntity obstypeEntity = new ObstypeEntity();
        ObsCategoryEntity obsCategoryEntity = new ObsCategoryEntity();
        obsCategoryEntity.setObsCategoryId(1000L);
        obstypeEntity.setObstypeId(100L);
        obstermEntity.setObstermId(1L);
        obstermEntity.setName("ABC");
        obstermEntity.setObscategory(obsCategoryEntity);
        obstermEntity.setObstype(obstypeEntity);
        obstermEntity.setCode("XYZ");
        return obstermEntity;
    }

}
