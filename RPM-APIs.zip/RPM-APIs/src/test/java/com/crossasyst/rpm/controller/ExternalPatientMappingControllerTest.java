package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.ExternalPatientMapping;
import com.crossasyst.rpm.model.Person;
import com.crossasyst.rpm.response.ExternalPatientMappingResponse;
import com.crossasyst.rpm.response.PatientResponse;
import com.crossasyst.rpm.service.ExternalPatientMappingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExternalPatientMappingControllerTest {

    ExternalPatientMappingController externalPatientMappingController;
    ExternalPatientMappingService externalPatientMappingService;


    @BeforeEach
    void setUp() {
        externalPatientMappingService = mock(ExternalPatientMappingService.class);
        externalPatientMappingController = new ExternalPatientMappingController(externalPatientMappingService);
    }

    @Test
    void testCreateExternalPatientMapping() {
        Long externalSystemId = 100L;
        ExternalPatientMapping externalPatientMapping = new ExternalPatientMapping();
        externalPatientMapping.setExternalPatientId(1000L);
        externalPatientMapping.setExternalPatientId(2000L);

        ExternalPatientMappingResponse externalPatientMappingResponse = new ExternalPatientMappingResponse();
        externalPatientMappingResponse.setExternalPatientMappingId(1L);

        when(externalPatientMappingService.createExternalPatientMapping(externalSystemId, externalPatientMapping)).thenReturn(externalPatientMappingResponse);
        ResponseEntity<ExternalPatientMappingResponse> response = externalPatientMappingController.createExternalPatientMapping(externalSystemId, externalPatientMapping);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(externalPatientMappingResponse, response.getBody());
    }


    @Test
    void testGetPatient() {
        Long externalPatientId = 1000L;

        Person person = new Person();
        person.setBirthDate(10051999);
        person.setGender("male");
        person.setEmailId("XYZ@");
        person.setFirstName("ABC");
        person.setLastName("DEF");
        person.setMiddleName("GFH");
        person.setPhoneNo(1234567899);
        person.setMaritalStatus("unmarried");
        person.setPreferredName("AAA");

        PatientResponse patientResponse = new PatientResponse();
        patientResponse.setPatientId(1L);

        patientResponse.setPerson(person);

        when(externalPatientMappingService.getPatient(externalPatientId)).thenReturn(patientResponse);

        ResponseEntity<PatientResponse> response = externalPatientMappingController.getPatient(externalPatientId);
        assertNotNull(response);
        assertEquals(patientResponse, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }
}
