package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ObstermEntity;
import com.crossasyst.rpm.entity.ObstypeEntity;
import com.crossasyst.rpm.entity.PatientEntity;
import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import com.crossasyst.rpm.entity.PatientObsEntity;
import com.crossasyst.rpm.mapper.PatientObsMapper;
import com.crossasyst.rpm.model.PatientObs;
import com.crossasyst.rpm.model.PatientObsDetail;
import com.crossasyst.rpm.repository.ObstermRepository;
import com.crossasyst.rpm.repository.ObstypeRepository;
import com.crossasyst.rpm.repository.PatientObsDetailRepository;
import com.crossasyst.rpm.repository.PatientObsRepository;
import com.crossasyst.rpm.response.PatientObsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PatientObsServiceTest {

    @InjectMocks
    PatientObsService patientObsService;
    @Mock
    PatientObsRepository patientObsRepository;

    @Mock
    ObstermRepository obstermRepository;

    @Mock
    ObstypeRepository obstypeRepository;

    @Mock
    PatientObsDetailRepository patientObsDetailRepository;

    @BeforeEach
    void setUp() {
        PatientObsMapper patientObsMapper = Mappers.getMapper(PatientObsMapper.class);
        ReflectionTestUtils.setField(patientObsService, "patientObsMapper", patientObsMapper);
    }


    @Test
    void testCreatePatientObs() {
        PatientObs patientObs = getPatientObs();
        PatientObsEntity patientObsEntity = new PatientObsEntity();
        patientObsEntity.setPatientObsId(1L);

        ObstermEntity obstermEntity = new ObstermEntity();
        obstermEntity.setObstermId(100L);
        when(obstermRepository.findById(anyLong())).thenReturn(Optional.of(obstermEntity));
        when(patientObsRepository.save(any(PatientObsEntity.class))).thenReturn(patientObsEntity);


        PatientObsResponse response = patientObsService.createPatientObs(patientObs);
        assertNotNull(response);
        assertEquals(patientObsEntity.getPatientObsId(), response.getPatientObsId());

    }

    @Test
    void testSavePatientObsWithNonNullPatientObsDetail() {
        PatientObsDetail patientObsDetail = new PatientObsDetail();
        patientObsDetail.setObstermId(1100L);
        patientObsDetail.setObstypeId(1200L);

        PatientObs patientObs = getPatientObs();
        patientObs.setPatientObsDetail(patientObsDetail);
        ObstypeEntity obstypeEntity = new ObstypeEntity();
        obstypeEntity.setObstypeId(1200L);
        obstypeEntity.setDisplayName("obs1");

        ObstermEntity obstermEntity = new ObstermEntity();
        obstermEntity.setObstermId(1100L);

        PatientObsDetailEntity patientObsDetailEntity = new PatientObsDetailEntity();
        patientObsDetailEntity.setPatientObs(getPatientObsEntity());
        patientObsDetailEntity.setObsterm(obstermEntity);
        patientObsDetailEntity.setObstype(obstypeEntity);

        when(obstypeRepository.findById(anyLong())).thenReturn(Optional.of(obstypeEntity));
        when(obstermRepository.findById(anyLong())).thenReturn(Optional.of(obstermEntity));
        when(patientObsDetailRepository.save(patientObsDetailEntity)).thenReturn(patientObsDetailEntity);
        PatientObsResponse response = patientObsService.createPatientObs(patientObs);
        assertNotNull(response);
        assertEquals(patientObsDetailEntity.getPatientObs().getPatientObsId(), response.getPatientObsId());
        verify(patientObsDetailRepository, times(1)).save(patientObsDetailEntity);
    }


    @Test
    void testGetPatientObsByPatientId() {
        PatientObsEntity patientObsEntity = new PatientObsEntity();
        PatientEntity patientEntity = new PatientEntity();
        ObstermEntity obstermEntity = new ObstermEntity();
        ObstypeEntity obstypeEntity = new ObstypeEntity();
        PatientObsDetailEntity patientObsDetailEntity = new PatientObsDetailEntity();
        obstermEntity.setObstermId(1100L);
        obstypeEntity.setObstypeId(1200L);
        patientObsDetailEntity.setObsterm(obstermEntity);
        patientObsDetailEntity.setObstype(obstypeEntity);


        patientObsEntity.setPatientObsId(1000L);
        patientEntity.setPatientId(1L);
        patientObsEntity.setObsterm(obstermEntity);
        patientObsEntity.setPatient(patientEntity);
        patientObsEntity.setValue(121D);
        patientObsEntity.setUomCode("uom");
        patientObsEntity.setEffectiveDateTime(LocalDateTime.parse("2023-04-28T15:30:00"));

        List<PatientObsEntity> patientObsEntityList = new ArrayList<>();
        patientObsEntityList.add(patientObsEntity);

        PatientObsResponse patientObsResponse = new PatientObsResponse();
        PatientObsDetail patientObsDetail = new PatientObsDetail();
        patientObsDetail.setObstermId(1100L);
        patientObsDetail.setObstypeId(1200L);

        patientObsResponse.setPatientObsId(1000L);
        patientObsResponse.setPatientId(1L);
        patientObsResponse.setValue(121D);
        patientObsResponse.setObstermId(100L);
        patientObsResponse.setEffectiveDateTime(LocalDateTime.parse("2023-04-28T15:30:00"));
        List<PatientObsResponse> patientObsResponseList = new ArrayList<>();
        patientObsResponseList.add(patientObsResponse);
        when(patientObsRepository.findByPatientId(anyLong())).thenReturn(patientObsEntityList);
        List<PatientObsResponse> responseList = patientObsService.getPatientObs(anyLong());
        assertNotNull(patientObsResponseList);
        assertEquals(patientObsResponseList.get(0), responseList.get(0));

    }

    @Test
    void testNullPatientObs() {
        PatientObs patientObs = null;
        Throwable exception = assertThrows(IllegalArgumentException.class, () -> patientObsService.createPatientObs(patientObs));
        assertEquals("Invalid data", exception.getMessage());
    }

    @Test
    void testGetPatientWithInvalidPatientId() {
        Long patientId = 1000L;
        List<PatientObsEntity> patientObsEntityList = new ArrayList<>();

        when(patientObsRepository.findByPatientId(patientId)).thenReturn(patientObsEntityList);

        List<PatientObsResponse> responseList = patientObsService.getPatientObs(patientId);
        assertEquals(Collections.emptyList(), responseList);
    }

    PatientObs getPatientObs() {
        PatientObs patientObs = new PatientObs();
        patientObs.setPatientId(1L);
        patientObs.setObstermId(1000L);
        patientObs.setValue(121D);
        patientObs.setUomCode("uom");
        patientObs.setEffectiveDateTime(LocalDateTime.parse("2023-04-28T15:30:00"));
        return patientObs;
    }

    PatientObsEntity getPatientObsEntity() {
        PatientObsEntity patientObsEntity = new PatientObsEntity();
        PatientEntity patientEntity = new PatientEntity();
        ObstermEntity obstermEntity = new ObstermEntity();
        obstermEntity.setObstermId(1100L);
        patientObsEntity.setObsterm(obstermEntity);
        patientEntity.setPatientId(1L);
        patientObsEntity.setPatient(patientEntity);
        patientObsEntity.setObsterm(obstermEntity);
        patientObsEntity.setValue(121D);
        patientObsEntity.setUomCode("uom");
        patientObsEntity.setEffectiveDateTime(LocalDateTime.parse("2023-04-28T15:30:00"));
        return patientObsEntity;
    }

}
