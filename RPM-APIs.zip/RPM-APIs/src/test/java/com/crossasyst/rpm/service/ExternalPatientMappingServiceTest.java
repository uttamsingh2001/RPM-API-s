package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ExternalPatientMappingEntity;
import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.mapper.ExternalPatientMappingMapper;
import com.crossasyst.rpm.model.ExternalPatientMapping;
import com.crossasyst.rpm.model.Person;
import com.crossasyst.rpm.repository.ExternalPatientMappingRepository;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalPatientMappingResponse;
import com.crossasyst.rpm.response.PatientResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ExternalPatientMappingServiceTest {

    @InjectMocks
    ExternalPatientMappingService externalPatientMappingService;
    @Mock
    ExternalSystemRepository externalSystemRepository;
    @Mock
    ExternalPatientMappingMapper externalPatientMappingMapper;
    @Mock
    ExternalPatientMappingRepository externalPatientMappingRepository;


    @Test
    void testCreateExternalPatientMapping() {

        ExternalPatientMapping externalPatientMapping = new ExternalPatientMapping();
        externalPatientMapping.setExternalPatientId(100L);
        externalPatientMapping.setPatientId(10L);

        ExternalSystemEntity externalSystemEntity = new ExternalSystemEntity();
        externalSystemEntity.setExternalSystemId(100L);
        externalSystemEntity.setName("ABC");


        ExternalPatientMappingEntity externalPatientMappingEntity = new ExternalPatientMappingEntity();
        externalPatientMappingEntity.setExternalPatientId(100L);
        externalPatientMappingEntity.setPatientId(10L);
        externalPatientMappingEntity.setExternalSystemEntity(externalSystemEntity);
        externalPatientMappingEntity.setExternalPatientMappingId(1100L);

        ExternalPatientMappingResponse externalPatientMappingResponse = new ExternalPatientMappingResponse();
        externalPatientMappingResponse.setExternalPatientMappingId(1100L);
        Long externalSystemId = 1L;

        when(externalSystemRepository.findById(externalSystemId)).thenReturn(Optional.of(externalSystemEntity));
        when(externalPatientMappingMapper.modelToEntity(any(ExternalPatientMapping.class))).thenReturn(externalPatientMappingEntity);
        when(externalPatientMappingRepository.save(externalPatientMappingEntity)).thenReturn(externalPatientMappingEntity);

        ExternalPatientMappingResponse response = externalPatientMappingService.createExternalPatientMapping(externalSystemId, externalPatientMapping);
        assertNotNull(response);
        assertEquals(externalPatientMappingResponse.getExternalPatientMappingId(), response.getExternalPatientMappingId());

    }

    @Test
    void testGetPatient() {
        long externalId = 1000;
        Person person = new Person();
        person.setBirthDate(10051999);
        person.setGender("male");
        person.setEmailId("XYZ@");
        person.setFirstName("ABC");
        person.setLastName("DEF");
        person.setMiddleName("GFH");
        person.setPhoneNo(1234567899);
        person.setMaritalStatus("unmarried");
        person.setPreferredName("AAA");
        PatientResponse patientResponse = new PatientResponse();
        patientResponse.setPatientId(1000L);
        patientResponse.setPerson(person);
        when(externalPatientMappingRepository.findPatientIdByExternalPatientId(externalId)).thenReturn(externalId);
        PatientResponse response = externalPatientMappingService.getPatient(externalId);
        assertNotNull(response);
        assertEquals(patientResponse.getPatientId(), response.getPatientId());
    }
}
