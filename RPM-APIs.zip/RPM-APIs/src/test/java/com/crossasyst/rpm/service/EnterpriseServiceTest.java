package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.EnterpriseEntity;
import com.crossasyst.rpm.mapper.EnterpriseMapper;
import com.crossasyst.rpm.model.Enterprise;
import com.crossasyst.rpm.repository.EnterpriseRepository;
import com.crossasyst.rpm.response.EnterpriseResponse;
import com.crossasyst.rpm.utils.CustomExceptionHandler;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class EnterpriseServiceTest {

    @InjectMocks
    private EnterpriseService enterpriseService;

    @Mock
    private EnterpriseRepository enterpriseRepository;

    @BeforeEach
    void setUp() {
        EnterpriseMapper enterpriseMapper = Mappers.getMapper(EnterpriseMapper.class);
        ReflectionTestUtils.setField(enterpriseService,"enterpriseMapper", enterpriseMapper);
    }

    @Test
    void testCreateEnterprise() {
        Enterprise enterprise = new Enterprise();
        enterprise.setName("Test");

        // setup
        EnterpriseEntity enterpriseEntity = new EnterpriseEntity();
        enterpriseEntity.setEnterpriseId(1234L);
        enterpriseEntity.setName("Test");

        //stubbing
        when(enterpriseRepository.save(Mockito.any())).thenReturn(enterpriseEntity);
        // actual call
        EnterpriseResponse enterpriseResponse = enterpriseService.createEnterprise(enterprise);

        //assertion
        Assertions.assertNotNull(enterpriseResponse);
        Assertions.assertEquals(1234L, enterpriseResponse.getEnterpriseId());

    }

    @Test
    void testGetAllEnterprise() {
        EnterpriseResponse enterpriseResponse = new EnterpriseResponse();
        enterpriseResponse.setEnterpriseId(1L);
        enterpriseResponse.setName("ABC");
        EnterpriseEntity enterpriseEntity = new EnterpriseEntity();
        enterpriseEntity.setEnterpriseId(1L);
        enterpriseEntity.setName("ABC");

        List<EnterpriseResponse> EnterpriseResponseList = List.of(enterpriseResponse);
        List<EnterpriseEntity> enterpriseEntityList = List.of(enterpriseEntity);

        when(enterpriseRepository.findByActiveTrue()).thenReturn(enterpriseEntityList);

        List<EnterpriseResponse> responseList = enterpriseService.getAllEnterprise();
        Assertions.assertNotNull(responseList);
        Assertions.assertEquals(responseList, EnterpriseResponseList);
    }

    @Test
    void testGetEnterprise() {
        EnterpriseEntity enterpriseEntity = new EnterpriseEntity();
        enterpriseEntity.setName("ABC");
        enterpriseEntity.setEnterpriseId(1000L);

        when(enterpriseRepository.findByIdAndActiveTrue(enterpriseEntity.getEnterpriseId())).thenReturn(Optional.of(enterpriseEntity));

        Enterprise enterprise = enterpriseService.getEnterprise(enterpriseEntity.getEnterpriseId());
        Assertions.assertNotNull(enterprise);
        Assertions.assertEquals(enterpriseEntity.getName(), enterprise.getName());

    }

    @Test
    void testGetEnterpriseException() {
        when(enterpriseRepository.findByIdAndActiveTrue(1000L)).thenThrow(new CustomExceptionHandler());
        Assertions.assertThrows(CustomExceptionHandler.class, () -> enterpriseService.getEnterprise(1000L));
    }

    @Test
    void testUpdateEnterprise() {
        EnterpriseEntity enterpriseEntity = new EnterpriseEntity();
        enterpriseEntity.setEnterpriseId(1000L);
        enterpriseEntity.setName("XYZ");

        Enterprise enterprise = new Enterprise();
        enterprise.setName("XYZ");

        when(enterpriseRepository.findByIdAndActiveTrue(anyLong())).thenReturn(Optional.of(enterpriseEntity));
        enterpriseService.updateEnterprise(1000L, enterprise);
        verify(enterpriseRepository, times(1)).save(enterpriseEntity);

    }


    @Test
    void testRemoveEnterprise() {
        EnterpriseEntity enterpriseEntity = new EnterpriseEntity();
        enterpriseEntity.setName("ABC");
        enterpriseEntity.setEnterpriseId(1000L);

        when(enterpriseRepository.findByIdAndActiveTrue(anyLong())).thenReturn(Optional.of(enterpriseEntity));

        enterpriseService.removeEnterprise(1000L);
        verify(enterpriseRepository, times(1)).deleteById(1000L);

    }
}


