package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.response.ExternalSystemParamResponse;
import com.crossasyst.rpm.service.ExternalSystemParamService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ExternalSystemParamControllerTest {


    ExternalSystemParamController externalSystemParamController;
    ExternalSystemParamService externalSystemParamService;

    @BeforeEach
    void setUp() {
        externalSystemParamService = mock(ExternalSystemParamService.class);
        externalSystemParamController = new ExternalSystemParamController(externalSystemParamService);
    }

    @Test
    void testCreateExternalSystemParam() {
        ExternalSystemParamResponse externalSystemParamResponse = new ExternalSystemParamResponse();
        when(externalSystemParamService.createExternalSystemParam(anyLong(), any(ExternalSystemParam.class))).thenReturn(externalSystemParamResponse);
        ResponseEntity<ExternalSystemParamResponse> response = externalSystemParamController.createExternalSystemParam(any(ExternalSystemParam.class), anyLong());
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    void testFindExternalSystemParam() {
        List<ExternalSystemParamResponse> externalSystemParamList = new ArrayList<>();
        ExternalSystemParamResponse externalSystemParamResponse = new ExternalSystemParamResponse();
        externalSystemParamResponse.setExternalSystemParamId(1L);
        externalSystemParamResponse.setKey("111");
        externalSystemParamResponse.setValue("ABC");
        externalSystemParamList.add(externalSystemParamResponse);
        when(externalSystemParamService.getAllExternalSystemParam(anyLong())).thenReturn(externalSystemParamList);
        ResponseEntity<List<ExternalSystemParamResponse>> response = externalSystemParamController.findExternalSystemParam(anyLong());
        assertNotNull(response);
        assertEquals(externalSystemParamList, response.getBody());

    }

    @Test
    void testUpdateExternalSystemParam() {
        ExternalSystemParam externalSystemParam = new ExternalSystemParam();
        externalSystemParam.setKey("1");
        externalSystemParam.setKey("ABC");

        ResponseEntity<String> response = externalSystemParamController.updateExternalSystemParam(1L, 2L, externalSystemParam);
        verify(externalSystemParamService, times(1)).updateExternalSystemParam(1L, 2L, externalSystemParam);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Id updated successfully", response.getBody());


    }

    @Test
    void testGetExternalSystemParamById() {
        ExternalSystemParam externalSystemParam = new ExternalSystemParam();
        externalSystemParam.setKey("sfsf");
        externalSystemParam.setValue("jgvjkj");
        when(externalSystemParamService.getExternalSystemParamById(anyLong(), anyLong())).thenReturn(externalSystemParam);
        ResponseEntity<ExternalSystemParam> response = externalSystemParamController.getExternalSystemParamById(anyLong(), anyLong());
        assertEquals(externalSystemParam, response.getBody());
    }
}
