package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.response.PatientObsDetailResponse;
import com.crossasyst.rpm.service.PatientObsDetailService;
import com.crossasyst.rpm.testUtils.MockUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PatientObsDetailControllerTest {

    @InjectMocks
    PatientObsDetailController patientObsDetailController;

    @Mock
    PatientObsDetailService patientObsDetailService;


    @Test
    void testGetPatientObsDetail() {
        List<PatientObsDetailResponse> patientObsDetailResponseList = new ArrayList<>();
        patientObsDetailResponseList.add(MockUtils.getPatientObsResponse());
        when(patientObsDetailService.getAllPatientObs(anyLong())).thenReturn((patientObsDetailResponseList));

        ResponseEntity<List<PatientObsDetailResponse>> response = patientObsDetailController.getPatientObsDetail(anyLong());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(patientObsDetailResponseList, response.getBody());
    }

    @Test
    void testGetPatientObsDetailWithNoData() {
        List<PatientObsDetailResponse> patientObsDetailResponseList = new ArrayList<>();
        when(patientObsDetailService.getAllPatientObs(anyLong())).thenReturn(patientObsDetailResponseList);
        ResponseEntity<List<PatientObsDetailResponse>> response = patientObsDetailController.getPatientObsDetail(anyLong());
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
}
