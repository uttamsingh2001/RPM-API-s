package com.crossasyst.rpm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpmApplicationTests {

	@Test
	void contextLoads() {
	}

}
