package com.crossasyst.rpm.entity;


import com.crossasyst.rpm.entity.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;



@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "ExternalSystem")
@Table(name ="external_system" )
public class ExternalSystemEntity extends BaseEntity {
    @Id
    @SequenceGenerator(name = "externalSystem_seq_id", sequenceName = "externalSystem_seq_id", initialValue = 1000, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "externalSystem_seq_id")
    @Column(name = "external_system_id")
    private Long externalSystemId;
    @Column(name = "name")
    private String name;
}