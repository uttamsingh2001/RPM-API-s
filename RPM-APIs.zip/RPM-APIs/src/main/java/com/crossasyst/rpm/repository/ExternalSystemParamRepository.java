package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.ExternalSystemParamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExternalSystemParamRepository extends JpaRepository<ExternalSystemParamEntity,Long> {
    @Query("SELECT a FROM ExternalSystemParamEntity a WHERE a.externalSystem.externalSystemId = ?1 ")
    List<ExternalSystemParamEntity> findByExternalSystemId(Long externalSystemId);
}
