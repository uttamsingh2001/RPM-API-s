package com.crossasyst.rpm.mapper;


import com.crossasyst.rpm.entity.PatientEntity;
import com.crossasyst.rpm.model.Patient;
import com.crossasyst.rpm.response.PatientResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;


import java.util.List;


@Mapper(componentModel = "spring")
public interface PatientMapper {

    PatientEntity toPatientEntity(Patient patient);

    Patient toPatient(PatientEntity patientEntity);

    List<PatientResponse> toPatientResponse(List<PatientEntity> patientEntities);




}