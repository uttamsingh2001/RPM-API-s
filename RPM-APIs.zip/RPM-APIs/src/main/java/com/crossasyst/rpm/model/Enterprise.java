package com.crossasyst.rpm.model;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Size;

@Data
@Validated
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Enterprise {
    @Size(max = 100, message = "EnterpriseService name maximum 100 character")
    private String name;

}

