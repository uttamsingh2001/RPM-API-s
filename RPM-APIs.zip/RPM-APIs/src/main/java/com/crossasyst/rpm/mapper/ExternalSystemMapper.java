package com.crossasyst.rpm.mapper;

import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.response.ExternalSystemResponse;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ExternalSystemMapper {
    ExternalSystemEntity modelToEntity(ExternalSystem externalSystem);
    List<ExternalSystemResponse> EntityToModel(List<ExternalSystemEntity> externalSystemEntity);

    List<ExternalSystem> entityToModel(List<ExternalSystemEntity> externalSystemEntities);


    ExternalSystem entityToModel(ExternalSystemEntity externalSystemEntity);

}

