package com.crossasyst.rpm.controller;


import com.crossasyst.rpm.model.ExternalPatientMapping;
import com.crossasyst.rpm.response.ExternalPatientMappingResponse;
import com.crossasyst.rpm.response.PatientResponse;
import com.crossasyst.rpm.service.ExternalPatientMappingService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Log4j2
@RequestMapping(path = "v1")

public class ExternalPatientMappingController {

    private final ExternalPatientMappingService externalPatientMappingService;

    @Autowired
    public ExternalPatientMappingController(ExternalPatientMappingService externalPatientMappingService) {
        this.externalPatientMappingService = externalPatientMappingService;
    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")
    @PostMapping(path = "/externalSystems/{externalSystemId}/externalPatientMappings", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExternalPatientMappingResponse> createExternalPatientMapping(@PathVariable Long externalSystemId, @RequestBody ExternalPatientMapping externalPatientMapping) {
        ExternalPatientMappingResponse externalPatientMappingResponse = externalPatientMappingService.createExternalPatientMapping(externalSystemId, externalPatientMapping);
        return new ResponseEntity<>(externalPatientMappingResponse, HttpStatus.CREATED);
    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")
    @GetMapping(path = "/externalPatientMapping/{externalPatientId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PatientResponse> getPatient(@PathVariable Long externalPatientId) {
        log.info("service");
        PatientResponse patientResponse = externalPatientMappingService.getPatient(externalPatientId);
        return new ResponseEntity<>(patientResponse, HttpStatus.OK);
    }
}