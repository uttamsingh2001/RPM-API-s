package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.PatientObsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PatientObsRepository extends JpaRepository<PatientObsEntity, Long> {


    @Query("SELECT po FROM PatientObsEntity po WHERE po.patient.patientId = :patientId")
    List<PatientObsEntity> findByPatientId(@Param("patientId") Long patientId);


}
