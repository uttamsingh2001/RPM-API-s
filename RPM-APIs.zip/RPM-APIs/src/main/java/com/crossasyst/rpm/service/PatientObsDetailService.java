package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import com.crossasyst.rpm.mapper.PatientObsDetailMapper;
import com.crossasyst.rpm.repository.PatientObsDetailRepository;
import com.crossasyst.rpm.response.PatientObsDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;


@Service
public class PatientObsDetailService {


    private final PatientObsDetailMapper patientObsDetailMapper;

    private final PatientObsDetailRepository patientObsDetailRepository;


    @Autowired
    public PatientObsDetailService(PatientObsDetailMapper patientObsDetailMapper, PatientObsDetailRepository patientObsDetailRepository) {
        this.patientObsDetailMapper = patientObsDetailMapper;
        this.patientObsDetailRepository = patientObsDetailRepository;

    }


    public List<PatientObsDetailResponse> getAllPatientObs(Long patientObsId) {
        List<PatientObsDetailEntity> patientObsDetailEntities = patientObsDetailRepository.findByPatientObsId(patientObsId);
        if (patientObsDetailEntities.isEmpty()) {
            return Collections.emptyList();
        }
        return patientObsDetailEntities.stream().map(patientObsDetailMapper::toPatientObsDetailResponse).toList();
    }
}
