package com.crossasyst.rpm.model;


import com.crossasyst.rpm.response.ExternalSystemResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class ExternalSystem  {
    private String name;
}
