package com.crossasyst.rpm.response;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PracticeResponse {
    private Long practiceId;
}
