package com.crossasyst.rpm.utils;

import lombok.Data;

@Data
public class ExceptionResponse {
    private String message;
}
