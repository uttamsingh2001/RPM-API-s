package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.response.ExternalSystemResponse;
import com.crossasyst.rpm.service.ExternalSystemService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@Tag(name = "External System", description = "External System")
@RequestMapping(path = "v1")
@RestController
public class ExternalSystemController {
    private final ExternalSystemService externalSystemService;

    public ExternalSystemController(ExternalSystemService externalSystemService) {
        this.externalSystemService = externalSystemService;
    }


    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @PostMapping(value = "/externalSystems", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExternalSystemResponse> createExternalSystem(@RequestBody @Valid ExternalSystem externalSystem) {
        ExternalSystemResponse externalSystemResponse = externalSystemService.createExternalSystem(externalSystem);
        return new ResponseEntity<>(externalSystemResponse, HttpStatus.OK);
    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")
    @GetMapping(value = "/externalSystems/{externalSystemId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExternalSystem> getExternalSystem(@PathVariable Long externalSystemId) {
        ExternalSystem externalSystem = externalSystemService.getExternalSystem(externalSystemId);
        return new ResponseEntity<>(externalSystem, HttpStatus.FOUND);
    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @GetMapping(value = "/externalSystems", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ExternalSystemResponse>> getAllExternalSystem() {
        List<ExternalSystemResponse> externalSystems = externalSystemService.getAllExternalSystem();
        return new ResponseEntity<>(externalSystems, HttpStatus.OK);

    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @PutMapping(value = "/externalSystems/{externalSystemId}")
    public ResponseEntity<ExternalSystem> updateExternalSystem(@PathVariable Long externalSystemId, @RequestBody ExternalSystem externalSystemRequest) {
        ExternalSystem externalSystem = externalSystemService.updateExternalSystem(externalSystemId, externalSystemRequest);
        return new ResponseEntity<>(externalSystem, HttpStatus.OK);
    }


}