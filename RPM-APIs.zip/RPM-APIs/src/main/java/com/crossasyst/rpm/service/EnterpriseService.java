package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.EnterpriseEntity;
import com.crossasyst.rpm.utils.CustomExceptionHandler;
import com.crossasyst.rpm.mapper.EnterpriseMapper;
import com.crossasyst.rpm.model.Enterprise;
import com.crossasyst.rpm.repository.EnterpriseRepository;
import com.crossasyst.rpm.response.EnterpriseResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Log4j2
public class EnterpriseService {

    private final EnterpriseMapper enterpriseMapper;

    private final EnterpriseRepository enterpriseRepository;

    @Autowired
    public EnterpriseService(EnterpriseMapper enterpriseMapper, EnterpriseRepository enterpriseRepository) {
        this.enterpriseMapper = enterpriseMapper;
        this.enterpriseRepository = enterpriseRepository;
    }

    public EnterpriseResponse createEnterprise(Enterprise enterprise) {
        EnterpriseEntity enterpriseEntity = enterpriseRepository.save(enterpriseMapper.toEnterpriseEntity(enterprise));
        log.info("enterprise details saved successfully on db..");
        return new EnterpriseResponse(enterpriseEntity.getEnterpriseId());
    }

    public List<EnterpriseResponse> getAllEnterprise() {
        List<EnterpriseEntity> enterpriseEntities = enterpriseRepository.findByActiveTrue();
        log.info("Fetching all active enterprises..");
        return enterpriseMapper.toEntityResponse(enterpriseEntities);
    }

    public Enterprise getEnterprise(Long enterpriseId) {
        Optional<EnterpriseEntity> enterpriseEntity = Optional.ofNullable(enterpriseRepository.findByIdAndActiveTrue(enterpriseId).orElseThrow(CustomExceptionHandler::new));
        Enterprise enterprise = new Enterprise();
        if (enterpriseEntity.isPresent()) {
            enterprise = enterpriseMapper.toEnterprise(enterpriseEntity.get());
        }
        log.info("Enterprise : {} ", enterprise.toString());
        return enterprise;
    }

    public void updateEnterprise(Long enterpriseId, Enterprise enterprise) {
        Optional<EnterpriseEntity> enterpriseEntity = Optional.ofNullable(enterpriseRepository.findByIdAndActiveTrue(enterpriseId).orElseThrow(CustomExceptionHandler::new));
        if (enterpriseEntity.isPresent()) {
            log.info("enterpriseId is present..");
            EnterpriseEntity enterpriseEntity1 = enterpriseMapper.toEnterpriseEntity(enterprise);
            enterpriseEntity1.setEnterpriseId(enterpriseEntity.get().getEnterpriseId());
            enterpriseRepository.save(enterpriseEntity1);
        }
    }


    public void removeEnterprise(Long enterpriseId) {
        Optional<EnterpriseEntity> enterpriseEntity = Optional.ofNullable(enterpriseRepository.findByIdAndActiveTrue(enterpriseId).orElseThrow(CustomExceptionHandler::new));
        if (enterpriseEntity.isPresent()) {
            log.info("enterpriseId is present..");
            enterpriseRepository.deleteById(enterpriseId);
        }
    }
}


