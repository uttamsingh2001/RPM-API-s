package com.crossasyst.rpm.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientObs {

    @NotNull
    private Long patientId;

    @NotNull
    private Long obstermId;

    @NotNull
    private Double value;

    @NotBlank
    private String uomCode;

    @NotNull
    private LocalDateTime effectiveDateTime;

    private PatientObsDetail patientObsDetail;


}
