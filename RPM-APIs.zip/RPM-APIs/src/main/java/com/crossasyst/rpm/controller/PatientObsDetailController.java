package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.response.PatientObsDetailResponse;
import com.crossasyst.rpm.service.PatientObsDetailService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Tag(name = "Create patientObsDetail", description = "Create patientObsDetail")
@RequestMapping(path = "v1")
@RestController
public class PatientObsDetailController {
    @Autowired
    private final PatientObsDetailService patientObsDetailService;

    public PatientObsDetailController(PatientObsDetailService patientObsDetailService) {
        this.patientObsDetailService = patientObsDetailService;
    }


    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")
    @GetMapping(path = "/{patientObsId}/patientObsDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PatientObsDetailResponse>> getPatientObsDetail(Long patientObsId) {
        List<PatientObsDetailResponse> res = patientObsDetailService.getAllPatientObs(patientObsId);
        if (CollectionUtils.isEmpty(res)) {
            return ResponseEntity.noContent().build();
        }
        return new ResponseEntity<>(res, HttpStatus.OK);

    }
}
