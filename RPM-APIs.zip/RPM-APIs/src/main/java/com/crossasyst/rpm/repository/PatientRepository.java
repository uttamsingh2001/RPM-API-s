package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.PatientEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<PatientEntity, Long> {
    @Override
    @Query("UPDATE PatientEntity a SET a.deleted = false WHERE a.patientId = ?1")
    @Modifying
    void deleteById(Long patientId);

    @Query("SELECT p FROM PatientEntity p WHERE p.id = ?1 AND p.deleted = false")
    Optional<PatientEntity> findByPatientIdAndDeletedFalse(Long patientId);

    @Query("SELECT p FROM PatientEntity p WHERE p.practice.practiceId = :practiceId and deleted = false ")
    List<PatientEntity> findPatientByPracticeId(Long practiceId);

    @Query("UPDATE PersonEntity p SET p.expired = true, p.expiredDate = :patientExpired " +
            "WHERE p.personId IN (SELECT pt.person.personId FROM PatientEntity pt WHERE pt.patientId = :patientId)")
    @Modifying
    void updateExpiredByPatientId(Long patientId, LocalDateTime patientExpired);

}

