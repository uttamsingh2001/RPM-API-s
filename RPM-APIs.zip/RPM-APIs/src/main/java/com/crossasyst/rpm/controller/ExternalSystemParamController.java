package com.crossasyst.rpm.controller;

import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.response.ExternalSystemParamResponse;
import com.crossasyst.rpm.service.ExternalSystemParamService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Tag(name = "External System param", description = "External System param")
@RequestMapping(path = "v1")
@RestController
public class ExternalSystemParamController {


    private final ExternalSystemParamService externalSystemParamService;


    @Autowired
    public ExternalSystemParamController(ExternalSystemParamService externalSystemParamService) {
        this.externalSystemParamService = externalSystemParamService;
    }


    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @PostMapping(value = "externalSystems/{externalSystemId}/externalSystemParams", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ExternalSystemParamResponse> createExternalSystemParam(@RequestBody @Valid ExternalSystemParam externalSystemParam, @PathVariable Long externalSystemId) {
        ExternalSystemParamResponse externalSystemParamResponse = externalSystemParamService.createExternalSystemParam(externalSystemId, externalSystemParam);
        return new ResponseEntity<>(externalSystemParamResponse, HttpStatus.CREATED);

    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @GetMapping(value = "externalSystems/{externalSystemId}/externalSystemParams", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ExternalSystemParamResponse>> findExternalSystemParam(@PathVariable Long externalSystemId) {
        List<ExternalSystemParamResponse> externalSystemParamResponses = externalSystemParamService.getAllExternalSystemParam(externalSystemId);
        return new ResponseEntity<>(externalSystemParamResponses, HttpStatus.OK);

    }

    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @PutMapping(path = "/externalSystems/{externalSystemId}/externalSystemParams/{externalSystemParamId}",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> updateExternalSystemParam(@PathVariable Long externalSystemId,@PathVariable Long externalSystemParamId, @RequestBody ExternalSystemParam externalSystemParam) {
        externalSystemParamService.updateExternalSystemParam(externalSystemId,externalSystemParamId, externalSystemParam);
        return new ResponseEntity<>("Id updated successfully", HttpStatus.OK);

    }
    @ApiResponse(responseCode = "200", description = "Success")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "404", description = "Not found")
    @ApiResponse(responseCode = "500", description = "System error")

    @GetMapping("externalSystems/{externalSystemId}/externalSystemParams/{externalSystemParamId}")
    public  ResponseEntity<ExternalSystemParam>getExternalSystemParamById(@PathVariable Long externalSystemId, @PathVariable Long externalSystemParamId){
        return new ResponseEntity<>(externalSystemParamService.getExternalSystemParamById(externalSystemId,externalSystemParamId),HttpStatus.OK);
    }


}