package com.crossasyst.rpm.response;

import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.model.base.Base;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExternalSystemParamResponse extends ExternalSystemParam {
    private Long externalSystemParamId;
}
