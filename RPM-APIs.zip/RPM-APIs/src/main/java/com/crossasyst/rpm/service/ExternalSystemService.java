package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.mapper.ExternalSystemMapper;
import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalSystemResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Log4j2
public class ExternalSystemService {
    private final ExternalSystemRepository externalSystemRepository;
    private final ExternalSystemMapper externalSystemMapper;
    public ExternalSystemService(ExternalSystemRepository externalSystemRepository, ExternalSystemMapper externalSystemMapper) {
        this.externalSystemRepository = externalSystemRepository;
        this.externalSystemMapper = externalSystemMapper;
    }
    public ExternalSystemResponse createExternalSystem(ExternalSystem externalSystem) {
        ExternalSystemEntity externalSystemEntity = externalSystemMapper.modelToEntity(externalSystem);
        ExternalSystemEntity save = externalSystemRepository.save(externalSystemEntity);
        log.info("system added successfully");
        ExternalSystemResponse externalSystemResponse = new ExternalSystemResponse();
        externalSystemResponse.setExternalSystemId(save.getExternalSystemId());
        log.info("Activity id{}", externalSystemEntity.getExternalSystemId());
        return externalSystemResponse;
    }
    public ExternalSystem getExternalSystem(Long externalSystemId) {
        Optional<ExternalSystemEntity> externalSystemEntity = externalSystemRepository.findById(externalSystemId);
        ExternalSystem externalSystem = new ExternalSystem();
        if (externalSystemEntity.isPresent()) {
            externalSystem = externalSystemMapper.entityToModel(externalSystemEntity.get());
        }
        return externalSystem;
    }
    public List<ExternalSystemResponse> getAllExternalSystem() {
        List<ExternalSystemEntity> externalSystemEntities = externalSystemRepository.findAll();
        return externalSystemMapper.EntityToModel(externalSystemEntities);
    }
    public ExternalSystem updateExternalSystem(Long externalSystemId, ExternalSystem externalSystem) {
        Optional<ExternalSystemEntity> externalSystemEntity = externalSystemRepository.findById(externalSystemId);
        if (externalSystemEntity.isPresent()) {
            ExternalSystemEntity externalSystemEntity1 = externalSystemMapper.modelToEntity(externalSystem);
            externalSystemEntity1.setExternalSystemId(externalSystemEntity.get().getExternalSystemId());
            externalSystemRepository.save(externalSystemEntity1);
        }
        return externalSystem;
    }


}
