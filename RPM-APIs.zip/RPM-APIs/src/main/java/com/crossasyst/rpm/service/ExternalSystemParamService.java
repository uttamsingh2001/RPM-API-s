package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.entity.ExternalSystemParamEntity;
import com.crossasyst.rpm.mapper.ExternalSystemParamMapper;
import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.repository.ExternalSystemParamRepository;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalSystemParamResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Log4j2
public class ExternalSystemParamService {
    private final ExternalSystemParamRepository externalSystemParamRepository;
    private final ExternalSystemRepository externalSystemRepository;

    private final ExternalSystemParamMapper externalSystemParamMapper;


    @Autowired
    public ExternalSystemParamService(ExternalSystemParamRepository externalSystemParamRepository, ExternalSystemRepository externalSystemRepository, ExternalSystemParamMapper externalSystemParamMapper) {
        this.externalSystemParamRepository = externalSystemParamRepository;
        this.externalSystemRepository = externalSystemRepository;
        this.externalSystemParamMapper = externalSystemParamMapper;
    }

    public ExternalSystemParamResponse createExternalSystemParam(Long externalSystemId, ExternalSystemParam externalSystemParamRequest) {

        Optional<ExternalSystemEntity> externalSystemEntity = externalSystemRepository.findById(externalSystemId);


        ExternalSystemParamResponse externalSystemParamResponse = new ExternalSystemParamResponse();
        if (externalSystemEntity.isPresent()) {
            ExternalSystemParamEntity externalSystemParamEntity = externalSystemParamMapper.modelToEntity(externalSystemParamRequest);
            externalSystemParamEntity.setExternalSystem(externalSystemEntity.get());
            ExternalSystemParamEntity externalSystemParam = externalSystemParamRepository.save(externalSystemParamEntity);
            externalSystemParamResponse.setExternalSystemParamId(externalSystemParam.getExternalSystemParamId());

        } else {
            log.info("External System not found with id " + externalSystemId);
        }

        return externalSystemParamResponse;


    }

    public List<ExternalSystemParamResponse> getAllExternalSystemParam(Long externalSystemId) {
        Optional<ExternalSystemEntity> externalSystem = externalSystemRepository.findById(externalSystemId);
        List<ExternalSystemParamResponse> externalSystemParamResponses = null;
        if (externalSystem.isPresent()) {
            List<ExternalSystemParamEntity> externalSystemParamRequestList = externalSystemParamRepository.findByExternalSystemId(externalSystemId);
            externalSystemParamResponses = externalSystemParamMapper.entityToModel(externalSystemParamRequestList);
        }
        return externalSystemParamResponses;
    }

    public ExternalSystemParam getExternalSystemParamById(Long externalSystemId, Long externalSystemParamId) {
        Optional<ExternalSystemEntity> externalSystemEntity = externalSystemRepository.findById(externalSystemId);
        ExternalSystemParam externalSystemParam = null;

        if (externalSystemEntity.isPresent()) {
            Optional<ExternalSystemParamEntity> externalSystemParamById = externalSystemParamRepository.findById(externalSystemParamId);
            if (externalSystemParamById.isPresent()) {
                externalSystemParam = externalSystemParamMapper.entityToModel(externalSystemParamById.get());
            } else {
                log.info("ExternalSystemParamEntity not found with id " + externalSystemParamId);
            }
        } else {
            log.info("ExternalSystemEntity not found with id " + externalSystemId);
        }

        return externalSystemParam;
    }


    public void updateExternalSystemParam(Long externalSystemId, Long externalSystemParamId, ExternalSystemParam externalSystemParam) {
        {
            Optional<ExternalSystemEntity> externalSystemEntity=externalSystemRepository.findById(externalSystemId);
            Optional<ExternalSystemParamEntity> externalSystemParamEntity=externalSystemParamRepository.findById(externalSystemParamId);
            if(externalSystemEntity.isPresent() && externalSystemParamEntity.isPresent()){
                ExternalSystemParamEntity externalSystemParamEntity1=externalSystemParamMapper.modelToEntity(externalSystemParam);
                externalSystemParamEntity1.setExternalSystemParamId(externalSystemParamEntity.get().getExternalSystemParamId());
                externalSystemParamEntity1.setExternalSystem(externalSystemParamEntity.get().getExternalSystem());

                externalSystemParamRepository.save(externalSystemParamEntity1);

                log.info("data updated successfully!!!");
            }

            else {
                log.error("Data not updated");
            }


        }
    }

}