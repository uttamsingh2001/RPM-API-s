package com.crossasyst.rpm.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "external_system_param")
public class ExternalSystemParamEntity {
    @Id
    @SequenceGenerator(name = "external_system_param_seq_id", sequenceName = "external_system_param_seq_id", initialValue = 1000, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "external_system_param_seq_id")
    @Column(name = "external_system_param_id")
    private Long externalSystemParamId;
    @Column(name = "key")
    private String key;
    @Column(name = "value")
    private String value;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "external_system_id")

    private ExternalSystemEntity externalSystem;
}

