package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.ExternalPatientMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ExternalPatientMappingRepository extends JpaRepository<ExternalPatientMappingEntity,Long> {


    @Query(value = "select e.patient_id from external_patient_mapping e where e.external_patient_id = ?1", nativeQuery = true)
    Long findPatientIdByExternalPatientId(Long externalPatientId);
}