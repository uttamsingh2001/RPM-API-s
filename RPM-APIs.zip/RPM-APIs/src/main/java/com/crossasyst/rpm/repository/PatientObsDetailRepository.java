package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;



@Repository
public interface PatientObsDetailRepository extends JpaRepository<PatientObsDetailEntity, Long> {

    @Query(value = "SELECT p FROM PatientObsDetailEntity p where p.patientObs.patientObsId = ?1")
    List<PatientObsDetailEntity> findByPatientObsId(Long patientObsId);
}
