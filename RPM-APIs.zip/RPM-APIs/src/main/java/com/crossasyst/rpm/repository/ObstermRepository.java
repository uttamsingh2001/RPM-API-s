package com.crossasyst.rpm.repository;

import com.crossasyst.rpm.entity.ObstermEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ObstermRepository extends JpaRepository<ObstermEntity, Long> {
}
