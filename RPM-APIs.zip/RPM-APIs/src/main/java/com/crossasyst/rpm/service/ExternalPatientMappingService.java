package com.crossasyst.rpm.service;


import com.crossasyst.rpm.entity.ExternalPatientMappingEntity;
import com.crossasyst.rpm.entity.ExternalSystemEntity;
import com.crossasyst.rpm.mapper.ExternalPatientMappingMapper;
import com.crossasyst.rpm.model.ExternalPatientMapping;
import com.crossasyst.rpm.repository.ExternalPatientMappingRepository;
import com.crossasyst.rpm.repository.ExternalSystemRepository;
import com.crossasyst.rpm.response.ExternalPatientMappingResponse;
import com.crossasyst.rpm.response.PatientResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Log4j2
public class ExternalPatientMappingService {


    private final ExternalPatientMappingMapper externalPatientMappingMapper;
    private final ExternalPatientMappingRepository externalPatientMappingRepository;
    private final ExternalSystemRepository externalSystemRepository;

    public ExternalPatientMappingService(ExternalPatientMappingMapper externalPatientMappingMapper, ExternalPatientMappingRepository externalPatientMappingRepository, ExternalSystemRepository externalSystemRepository) {
        this.externalPatientMappingMapper = externalPatientMappingMapper;
        this.externalPatientMappingRepository = externalPatientMappingRepository;
        this.externalSystemRepository = externalSystemRepository;
    }

    public ExternalPatientMappingResponse createExternalPatientMapping(Long externalSystemId, ExternalPatientMapping externalPatientMapping) {
        Optional<ExternalSystemEntity> externalSystem = externalSystemRepository.findById(externalSystemId);
        ExternalPatientMappingEntity externalPatientMappingEntity = new ExternalPatientMappingEntity();
        ExternalPatientMappingResponse externalPatientMappingResponse = new ExternalPatientMappingResponse();

        if (externalSystem.isPresent()) {
            externalPatientMappingEntity = externalPatientMappingMapper.modelToEntity(externalPatientMapping);
            externalPatientMappingEntity.setExternalSystemEntity(externalSystem.get());
            externalPatientMappingRepository.save(externalPatientMappingEntity);
        }
        externalPatientMappingResponse.setExternalPatientMappingId(externalPatientMappingEntity.getExternalPatientMappingId());
        return externalPatientMappingResponse;
    }

    public PatientResponse getPatient(Long externalPatientId) {
        Long patientId = externalPatientMappingRepository.findPatientIdByExternalPatientId(externalPatientId);
        log.info("Patient ID: " + patientId);
        PatientResponse patientResponse = new PatientResponse();
        patientResponse.setPatientId(patientId);
        return patientResponse;
    }
}
