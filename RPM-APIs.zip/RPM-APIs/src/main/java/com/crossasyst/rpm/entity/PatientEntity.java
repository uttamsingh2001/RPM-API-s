package com.crossasyst.rpm.entity;


import com.crossasyst.rpm.entity.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "patient")
public class PatientEntity extends BaseEntity {
    @Id
    @SequenceGenerator(name = "patient_seq_id", sequenceName = "patient_seq_id", initialValue = 1000, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patient_seq_id")
    @Column(name = "patient_id")
    private Long patientId;

    private Boolean deleted = Boolean.FALSE;
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "person_id")
    private PersonEntity person;

    @ManyToOne
    @JoinColumn(name = "practice_id")
    private PracticeEntity practice;


}