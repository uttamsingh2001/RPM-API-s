package com.crossasyst.rpm.mapper;

import com.crossasyst.rpm.entity.ExternalPatientMappingEntity;
import com.crossasyst.rpm.model.ExternalPatientMapping;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ExternalPatientMappingMapper {


    ExternalPatientMappingEntity modelToEntity(ExternalPatientMapping externalPatientMapping);

    ExternalPatientMapping entityToModel(ExternalPatientMappingEntity externalPatientMappingEntity);

}
