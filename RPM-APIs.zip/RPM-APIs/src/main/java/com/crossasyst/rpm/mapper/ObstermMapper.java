package com.crossasyst.rpm.mapper;

import com.crossasyst.rpm.entity.ObstermEntity;
import com.crossasyst.rpm.model.Obsterm;
import com.crossasyst.rpm.response.ObstermResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.stereotype.Component;


@Component
@Mapper(componentModel = "spring")
public interface ObstermMapper {

    @Mapping(source = "obscategory.obsCategoryId", target = "obscategoryId")
    @Mapping(source = "obstype.obstypeId", target = "obstypeId")
    ObstermResponse toObstermResponse(ObstermEntity obstermEntities);

    @Mapping(source = "obscategory.obsCategoryId", target = "obscategoryId")
    @Mapping(source = "obstype.obstypeId", target = "obstypeId")
    Obsterm toObsterm(ObstermEntity obstermEntity);


}