package com.crossasyst.rpm.response;

import com.crossasyst.rpm.model.ExternalSystem;
import com.crossasyst.rpm.model.base.Base;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class ExternalSystemResponse extends ExternalSystem {
    private Long externalSystemId;
}
