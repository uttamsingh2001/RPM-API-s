package com.crossasyst.rpm.entity;

import com.crossasyst.rpm.entity.base.BaseEntity;
import com.crossasyst.rpm.model.base.Base;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "practice")
public class PracticeEntity extends BaseEntity {
    @Id
    @SequenceGenerator(name = "practice_seq_id", sequenceName = "practice_seq_id", initialValue = 10001, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "practice_seq_id")
    @Column(name = "practice_id")
    private Long practiceId;

    @Column(name = "name")
    private String name;

    @Column(name = "active")
    private boolean active=Boolean.TRUE;

    @ManyToOne
    @JoinColumn(name = "enterprise_id")
    private EnterpriseEntity enterpriseEntity;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "practice_id")
    private List<PatientEntity> patientEntityList;
}