package com.crossasyst.rpm.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "external_patient_mapping")
public class ExternalPatientMappingEntity {


    @Id
    @SequenceGenerator(name = "external_patient_mapping_sequence_id", sequenceName = "external_patient_mapping_sequence_id", initialValue = 100, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "external_patient_mapping_sequence_id")

    @Column(name = "external_patient_mapping_id")
    private Long externalPatientMappingId;

    @Column(name = "external_patient_id")
    private Long externalPatientId;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "external_system_id")
    private ExternalSystemEntity externalSystemEntity;

    @Column(name = "patient_id")
    private Long patientId;

}
