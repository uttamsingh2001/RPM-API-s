package com.crossasyst.rpm.service;

import com.crossasyst.rpm.entity.EnterpriseEntity;
import com.crossasyst.rpm.entity.PatientEntity;
import com.crossasyst.rpm.entity.PersonEntity;
import com.crossasyst.rpm.entity.PracticeEntity;
import com.crossasyst.rpm.mapper.PatientMapper;
import com.crossasyst.rpm.model.Patient;
import com.crossasyst.rpm.model.PatientExpired;
import com.crossasyst.rpm.model.Person;
import com.crossasyst.rpm.model.PhotoUrl;
import com.crossasyst.rpm.repository.PatientRepository;
import com.crossasyst.rpm.repository.PracticeRepository;
import com.crossasyst.rpm.response.PatientResponse;
import com.crossasyst.rpm.utils.CustomExceptionHandler;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Log4j2
public class PatientService {
    private final PatientRepository patientRepository;
    private final PatientMapper patientMapper;
    private final PracticeRepository practiceRepository;

    public PatientService(PatientRepository patientRepository, PatientMapper patientMapper, PracticeRepository practiceRepository) {
        this.patientRepository = patientRepository;
        this.patientMapper = patientMapper;
        this.practiceRepository = practiceRepository;
    }

    public PatientResponse createPatient(Long practiceId, Patient patient) {
        Optional<PracticeEntity> practiceEntity = Optional.ofNullable(practiceRepository.findById(practiceId)).orElseThrow(CustomExceptionHandler::new);
        PatientEntity patientEntity = new PatientEntity();
        if (practiceEntity.isPresent()) {
            patientEntity = patientMapper.toPatientEntity(patient);
            patientEntity.setPractice(practiceEntity.get());
            patientRepository.save(patientEntity);
        }
        return new PatientResponse(patientEntity.getPatientId());
    }

    public Patient getPatientById(Long patientId) {
        Optional<PatientEntity> patientEntity = Optional.ofNullable(patientRepository.findByPatientIdAndDeletedFalse(patientId)).orElseThrow(CustomExceptionHandler::new);
        Patient patient = new Patient();
        if (patientEntity.isPresent()) {
            patient = patientMapper.toPatient(patientEntity.get());
        }
        return patient;
    }

    public List<PatientResponse> getAllPatient(Long practiceId) {
        Optional<List<PatientEntity>> patientEntity = Optional.ofNullable(patientRepository.findPatientByPracticeId(practiceId));
        List<PatientResponse> patientResponse = null;
        if (patientEntity.isPresent()) {
            patientResponse = patientMapper.toPatientResponse(patientEntity.get());
        }
        return patientResponse;

    }

    public void deleteById(Long patientId) {
        Optional<PatientEntity> patientEntity = Optional.ofNullable(patientRepository.findByPatientIdAndDeletedFalse(patientId)).orElseThrow(CustomExceptionHandler::new);
        if (patientEntity.isPresent()) {
            patientRepository.deleteById(patientId);
        }
    }

    public void updatePatient(Long patientId, Patient patient) {
        log.info("fetching persons");
        Optional<PatientEntity> patientEntity = Optional.ofNullable(patientRepository.findByPatientIdAndDeletedFalse(patientId).orElseThrow(CustomExceptionHandler::new));

        if (patientEntity.isPresent()) {
            PatientEntity patient1 = patientMapper.toPatientEntity(patient);
            patient1.getPerson().setPersonId(patientEntity.get().getPerson().getPersonId());
            patient1.setPatientId(patientEntity.get().getPatientId());
            patientRepository.save(patient1);
        }


    }

    @Transactional
    public void updatePatientExpiredById(Long patientId, PatientExpired patientExpired) {
        patientRepository.updateExpiredByPatientId(patientId, patientExpired.getExpiredDate());
    }

    public void updatePatientPhotoById(Long patientId, PhotoUrl photoUrl) {
        Optional<PatientEntity> patientEntity = Optional.ofNullable(patientRepository.findByPatientIdAndDeletedFalse(patientId).orElseThrow(CustomExceptionHandler::new));
        if (patientEntity.isPresent()) {
            PatientEntity patient = patientEntity.get();
            patient.getPerson().setPhotoUrl(photoUrl.getPatientPhotoUrl());
            patientRepository.save(patient);
        }
    }

}
