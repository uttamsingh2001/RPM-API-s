package com.crossasyst.rpm.mapper;

import com.crossasyst.rpm.entity.PatientObsDetailEntity;
import com.crossasyst.rpm.response.PatientObsDetailResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;



@Mapper(componentModel = "spring")
public interface PatientObsDetailMapper {

     @Mapping(source = "obsterm.obstermId", target = "obstermId")
     @Mapping(source = "obstype.obstypeId", target = "obstypeId")
    PatientObsDetailResponse toPatientObsDetailResponse(PatientObsDetailEntity patientObsDetailEntity);
}
