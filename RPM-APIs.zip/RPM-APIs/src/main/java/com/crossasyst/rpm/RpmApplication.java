package com.crossasyst.rpm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpmApplication {


    public static void main(String[] args) {
        SpringApplication.run(RpmApplication.class, args);
    }

}
