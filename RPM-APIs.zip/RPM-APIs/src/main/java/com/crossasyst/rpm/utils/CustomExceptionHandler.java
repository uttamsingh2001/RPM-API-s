package com.crossasyst.rpm.utils;

public class CustomExceptionHandler extends  RuntimeException{

}
