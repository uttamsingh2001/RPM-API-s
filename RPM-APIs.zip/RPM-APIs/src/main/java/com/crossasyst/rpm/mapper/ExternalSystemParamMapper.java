package com.crossasyst.rpm.mapper;



import com.crossasyst.rpm.entity.ExternalSystemParamEntity;
import com.crossasyst.rpm.model.ExternalSystemParam;
import com.crossasyst.rpm.response.ExternalSystemParamResponse;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ExternalSystemParamMapper {
    ExternalSystemParamEntity modelToEntity(ExternalSystemParam externalSystemParam);

    List<ExternalSystemParamResponse> entityToModel(List<ExternalSystemParamEntity> externalSystemParamEntities);


    ExternalSystemParam entityToModel(ExternalSystemParamEntity externalSystemParamEntity);

    ExternalSystemParamEntity entityToModel(ExternalSystemParam externalSystemParam);
}

