package com.crossasyst.rpm.response;


import com.crossasyst.rpm.model.Patient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientResponse extends Patient {
    private Long patientId;
}