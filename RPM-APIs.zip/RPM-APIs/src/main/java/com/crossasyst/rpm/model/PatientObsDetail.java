package com.crossasyst.rpm.model;

import lombok.Data;


@Data
public class PatientObsDetail {

    private Long obstermId;


    private Long obstypeId;
}
